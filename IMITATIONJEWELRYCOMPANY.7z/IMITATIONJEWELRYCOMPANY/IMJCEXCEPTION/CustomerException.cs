﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMJCEXCEPTION
{
    public class CustomerException:ApplicationException
    {
        public CustomerException()
        {

        }
        public CustomerException(string Message) : base(Message)
        {

        }
    }
}
