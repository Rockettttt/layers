﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IMJCDAL;
using IMJCENTITY;
using IMJCEXCEPTION;

namespace IMJCBLL
{
    public class CustomerBLL
    {
        CustomerDAL customerDAL = new CustomerDAL();
        public bool AddCustomerBLL(Customer newCustomer)
        {
            bool isCustomerAdded = false;
            if (ValidateCustomer(newCustomer))
            {
                isCustomerAdded = customerDAL.AddCustomerDAL(newCustomer);
            }
            //To be Implemented
            return isCustomerAdded;
        }
        private bool ValidateCustomer(Customer newCustomer)
        {
            bool validCustomer = true;
            return validCustomer;
        }
        public List<Customer> GetAllCustomersBLL()
        {
            return customerDAL.GetAllCustomerDAL();
        }

        public List<Customer> SearchbyCityBLL(string City)
        {
            return customerDAL.SearchbyCityDAL(City);


        }
        public bool SerializeCustomerBLL()
        {
            return customerDAL.SerializeCustomerDAL();
        }
        public List<Customer> DeSerializeCustomersBLL()
        {
            return customerDAL.DeserializeCustomersDAL();
        }
    }
}
