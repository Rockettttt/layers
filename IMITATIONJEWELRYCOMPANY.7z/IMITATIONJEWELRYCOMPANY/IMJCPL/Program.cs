﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IMJCBLL;
using IMJCENTITY;
using IMJCEXCEPTION;

namespace IMJCPL
{
    class Program
    {
       static  CustomerBLL customerBLL = new CustomerBLL();
        static void Main(string[] args)
        {

            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                bool checkChoice;
                checkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!checkChoice)
                {
                    Console.WriteLine("Invalid Input");
                }

                switch (choice)
                {


                    case 1:
                        AddCustomerPL();
                        break;
                    case 2:
                        GetAllCustomersPL();
                        break;
                    case 3:
                        SearchbyCityPL();
                        break;
                    case 4:
                        SerializeCustomerPL();
                        break;
                    case 5:
                        DeserializeCustomersPL();

                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }

            } while (choice != 0);
        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n*****************Imatation Jewelry Company **********");
            Console.WriteLine("1. Add Dealer");
            Console.WriteLine("2. List All Dealers");
            Console.WriteLine("3. Search Dealer By Product Category");
            Console.WriteLine("4. Serialize All Dealers");
            Console.WriteLine("5. Deserialize All Dealers");
            Console.WriteLine("*******************\n");


        }
        private static void AddCustomerPL()
        {
            try
            {
                //Accept input from user
                Console.WriteLine("Enter Customer Id:");
                string CustomerId = Console.ReadLine();
                Console.WriteLine("Enter Customer Name:");
                string CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Address");
                string Address = Console.ReadLine();
                Console.WriteLine("Enter City");
                string City = Console.ReadLine();
                Console.WriteLine("Enter Contact");
                string Contact = Console.ReadLine();
                Console.WriteLine("Enter Email");
                string Email = Console.ReadLine();




                //Pass input to create new object
                Customer newCustomer = new Customer();

                newCustomer.CustomerId = CustomerId;
                newCustomer.CustomerName = CustomerName;
                newCustomer.Address = Address;
                newCustomer.City = City;
                newCustomer.Contact = Contact;
                newCustomer.Email = Email;

                
                bool isCustomerAdded = customerBLL.AddCustomerBLL(newCustomer);
                if (isCustomerAdded)
                {
                    Console.WriteLine("Customer added successfully.");
                }
                else
                {
                    Console.WriteLine("failed to add customer.");
                }



            }
            catch (CustomerException exception)
            {
                Console.WriteLine("Exception Occured:" + exception.Message);

            }
        }
        //get all Customer details
        public static void GetAllCustomersPL()
        {
            List<Customer> CustomersList = customerBLL.GetAllCustomersBLL();
            Console.WriteLine("-----------------");
            Console.WriteLine("CustomerId" + "\t" + "Customer Name" + "\t" + " Address" + "\t" + " Email Address" + "\t" + "Contact" + "\t"
                     + "City");
            Console.WriteLine("------------------------------------\n");

            foreach (Customer customer in CustomersList)
            {
                Console.WriteLine(customer.CustomerId + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.Email + "\t" + customer.Contact + "\t"
                     + customer.City);
                Console.WriteLine("------------------------------------");
            }
        }

        public static void SearchbyCityPL()
        {
            Console.WriteLine("Enter the City");
            string City = Console.ReadLine();
            List<Customer> searchCity = customerBLL.SearchbyCityBLL(City);
            Console.WriteLine("-----------------");
            Console.WriteLine("CustomerId" + "\t" + "Customer Name" + "\t" + " Address" + "\t" + " Email Address" + "\t" + "Contact" + "\t"
                     + "City");
            Console.WriteLine("------------------------------------\n");

            foreach (Customer customer in searchCity)
            {
                Console.WriteLine(customer.CustomerId + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.Email + "\t" + customer.Contact + "\t"
                     + customer.City);
                Console.WriteLine("------------------------------------");
            }

        }
        private static void SerializeCustomerPL()
        {
            if (customerBLL.SerializeCustomerBLL())
            {
                Console.WriteLine("  customer Details added Succesfully");
            }
            else
            {
                Console.WriteLine("customer Details not added");
            }
        }
        private static void DeserializeCustomersPL()
        {
            List<Customer> DeSerializeCustomers = customerBLL.DeSerializeCustomersBLL();
            Console.WriteLine("-----------------");
            Console.WriteLine("CustomerId" + "\t" + "Customer Name" + "\t" + " Address" + "\t" + " Email Address" + "\t" + "Contact" + "\t"
                     + "City");
            Console.WriteLine("------------------------------------\n");

            foreach (Customer customer in DeSerializeCustomers)
            {
                Console.WriteLine(customer.CustomerId + "\t" + customer.CustomerName + "\t" + customer.Address + "\t" + customer.Email + "\t" + customer.Contact + "\t"
                     + customer.City);
                Console.WriteLine("------------------------------------");
            }

        }

    }

}
