﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IMJCENTITY;
using IMJCEXCEPTION;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace IMJCDAL
{
    public class CustomerDAL
    {
        public static List<Customer> customers = new List<Customer>();
        public bool AddCustomerDAL(Customer newCustomer)
        {
            bool isCustomerAdded = false;
            try
            {
                customers.Add(newCustomer);
                isCustomerAdded = true;
            }
            catch (SystemException exception)
            {
                throw new CustomerException(exception.Message);
            }
            return isCustomerAdded;
        }
        //get all method
        public List<Customer> GetAllCustomerDAL()
        {
            return customers;
        }
        //Search city
        public List<Customer> SearchbyCityDAL(string City)
        {
            return customers.FindAll(customer => customer.City.Equals(City));
        }
        //serialization
        public bool SerializeCustomerDAL()
        {
            bool areCustomersAdded = false;
            try
            {
                FileStream fs = new FileStream("CustomerInfo.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, customers);
                fs.Close();
                areCustomersAdded = true;
            }
            catch (SystemException exception)
            {

                throw new CustomerException(exception.Message);
            }
            return areCustomersAdded;
        }
        //deserialize
        public List<Customer> DeserializeCustomersDAL()
        {
            List<Customer> DeSerializeCustomers;
            try
            {
                FileStream fs = new FileStream("CustomerInfo.txt", FileMode.Open);
                BinaryFormatter bin = new BinaryFormatter();
                DeSerializeCustomers = (List<Customer>)bin.Deserialize(fs);
                fs.Close();

            }
            catch (SystemException exception)
            {

                throw new CustomerException(exception.Message);
            }
            return DeSerializeCustomers;
        }
    }
}
